﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Notifications;
using Windows.ApplicationModel.DataTransfer;
using Windows.UI.Core;
using Windows.Storage.AccessCache;
using App2.Models;
using App2.ViewModels;
using App2.Services;
using SQLitePCL;
using System.Text;
using Windows.Graphics.Imaging;
// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace App2
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private string title;
        private string detail;
        private string path;
        private string name;
        //public String currentPath;
        public TodoItemViewModel ViewModel = ((App)App.Current).ViewModel;

        public MainPage()
        {
            this.InitializeComponent();
            var items = Enum.GetNames(typeof(ToastTemplateType));
            path = Directory.GetCurrentDirectory() + "\\Assets\\background.jpg";
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility =
                    AppViewBackButtonVisibility.Collapsed;
            name = "background.jpg";
        }


        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            if (Window.Current.Bounds.Width < 800)
            {
                ViewModel.SelectedItem = null;
                Frame.Navigate(typeof(NewPage));
            }
            else
            {
                Title.Text = "";
                Detail.Text = "";
                DueDate.Date = DateTimeOffset.Now.Date;
                CreateButton.Content = "Create";
            }
        }


        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            ((App)App.Current).ViewModel.SelectedItem = (Models.TodoItem)(e.ClickedItem);

            if (Window.Current.Bounds.Width < 800)
            {
                Frame.Navigate(typeof(NewPage));
            }
            else
            {
                CreateButton.Content = "Update";
                Title.Text = ViewModel.SelectedItem.title;
                Detail.Text = ViewModel.SelectedItem.detail;
                DueDate.Date = ViewModel.SelectedItem.date;
                Main_Pic.Source = ViewModel.SelectedItem.imageSource;
                name = ((App)App.Current).ViewModel.SelectedItem.imagename;
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Title.Text = "";
            Detail.Text = "";
            DueDate.Date = DateTimeOffset.Now.Date;
            //Frame.Navigate(typeof(MainPage));
        }

        private async void Main_SelectPic(object sender, RoutedEventArgs e)
        {
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".png");
            openPicker.FileTypeFilter.Add(".gif");
            StorageFile file = await openPicker.PickSingleFileAsync();
            if (file != null)
            {

                ApplicationData.Current.LocalSettings.Values["TempImage"] = StorageApplicationPermissions.FutureAccessList.Add(file);

                String ImagePath = Directory.GetCurrentDirectory() + "\\Assets\\";
                StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(ImagePath);
                await file.CopyAsync(folder, file.Name, NameCollisionOption.ReplaceExisting);

                StorageFile newFile = await folder.GetFileAsync(file.Name);

                if (newFile != null)
                {
                    using (IRandomAccessStream fileStream =
                await newFile.OpenAsync(FileAccessMode.Read))
                    {
                        BitmapImage bitmapImage = new BitmapImage();
                        bitmapImage.SetSource(fileStream);
                        //bitmapImage.SetSourceAsync(fileStream);
                        Main_Pic.Source = bitmapImage;
                        name = file.Name;

                    }
                }

            }
        }


        private async void setDefaultImage()
        {
            String ImagePath = Directory.GetCurrentDirectory() + "\\Assets\\";
            StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(ImagePath);
            StorageFile file = await folder.GetFileAsync("background.jpg");
            using (Windows.Storage.Streams.IRandomAccessStream fileStream =
                await file.OpenAsync(FileAccessMode.Read))
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.SetSource(fileStream);
                Main_Pic.Source = bitmapImage;
                name = file.Name;
            }
        }





        private async void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            String emptys = "";
            if (Title.Text.Equals(""))
            {
                emptys += (emptys.Equals("") ? "You did not set:\n" : "");
                emptys += "\tTitle\n";
            }
            if (Detail.Text.Equals(""))
            {
                emptys += (emptys.Equals("") ? "You did not set:\n" : "");
                emptys += "\tDetails\n";
            }
            if (DueDate.Date < DateTime.Now.Date)
            {
                emptys += (emptys.Equals("") ? "" : "and ");
                emptys += "the time is earlier than now";
            }
            if (!emptys.Equals(""))
            {
                ContentDialog content_dialog = new ContentDialog()
                {
                    Title = "Error",
                    Content = emptys,
                    PrimaryButtonText = "Get",
                };
                await content_dialog.ShowAsync();
            }
            else
            {
                if (CreateButton.Content.Equals("Create"))
                {
                    ((App)App.Current).ViewModel.AddTodoItem(Title.Text, Detail.Text, DueDate.Date.Date, Main_Pic.Source, name);

                    //Update_tile.UpdateTile(Title.Text, Detail.Text);

                    Title.Text = "";
                    Detail.Text = "";
                    DueDate.Date = DateTimeOffset.Now.Date;
                    ContentDialog content_dialog = new ContentDialog()
                    {
                        Title = "Create",
                        Content = "Success!",
                        PrimaryButtonText = "OK",
                    };
                    

                    await content_dialog.ShowAsync();
                }
                else
                {
                    ((App)App.Current).ViewModel.UpdateTodoItem(Title.Text, Detail.Text, DueDate.Date.Date, ViewModel.SelectedItem.completed, Main_Pic.Source, name);
                    ContentDialog content_dialog = new ContentDialog()
                    {
                        Title = "Update",
                        Content = "Success!",
                        PrimaryButtonText = "OK",
                    };

                    content_dialog.PrimaryButtonClick += (_s, _e) => {
                        Frame.Navigate(typeof(MainPage));
                    };

                    await content_dialog.ShowAsync();
                }
                circulationUpdate();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var data = (sender as FrameworkElement).DataContext;
            var item = ToDoListView.ContainerFromItem(data) as ListViewItem;
            ((App)App.Current).ViewModel.SelectedItem = item.Content as TodoItem;
            ((App)App.Current).ViewModel.RemoveTodoItem();
        }

        private void Share_Click(object sender, RoutedEventArgs e)
        {
            dynamic d = e.OriginalSource;
            title = d.DataContext.title;
            detail = d.DataContext.detail;
            if (d.DataContext.imageSource.UriSource != null)
            {
                path = d.DataContext.imageSource.UriSource.AbsoluteUri;
            }
            //path = Directory.GetCurrentDirectory() + "\\Assets\\background.jpg";
            DataTransferManager.ShowShareUI();
            

        }

        private void OnShareDataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            var request = args.Request;
            request.Data.Properties.Title = title;
            request.Data.Properties.Description = detail;
            request.Data.SetText(title + " ， " + detail + "。 好好学现操");

            request.Data.SetBitmap(RandomAccessStreamReference.CreateFromUri(new Uri(path)));
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            DataTransferManager.GetForCurrentView().DataRequested -= OnShareDataRequested;

            bool suspending = ((App)App.Current).isssuspend;
            if (suspending)
            {
                var composite = new ApplicationDataCompositeValue();
                composite["count"] = ((App)App.Current).ViewModel.AllItems.Count;
                composite["Title"] = Title.Text;
                composite["Detail"] = Detail.Text;
                composite["Date"] = DueDate.Date;
                /*for (int i = 0;i < ((App)App.Current).ViewModel.AllItems.Count; i++)
                {
                    composite["Title"+i] = ((App)App.Current).ViewModel.AllItems[i].title;
                    composite["Details"+i] = ((App)App.Current).ViewModel.AllItems[i].detail;
                    composite["Date"+i] = ((App)App.Current).ViewModel.AllItems[i].date;
                    composite["Visible"+i] = ((App)App.Current).ViewModel.AllItems[i].completed;

                }*/
                
                ApplicationData.Current.LocalSettings.Values["MainPage"] = composite;
            }

        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            DataTransferManager.GetForCurrentView().DataRequested += OnShareDataRequested;

            if (e.NavigationMode == NavigationMode.New)
            {
                ApplicationData.Current.LocalSettings.Values.Remove("MainPage");
                ApplicationData.Current.LocalSettings.Values["TempImage"] = null;
            }
            else
            {
                if (ApplicationData.Current.LocalSettings.Values["TempImage"] != null)
                {
                    StorageFile temp;
                    temp = await StorageApplicationPermissions.FutureAccessList.GetFileAsync((string)ApplicationData.Current.LocalSettings.Values["TempImage"]);
                    IRandomAccessStream ir = await temp.OpenAsync(FileAccessMode.Read);
                    BitmapImage bi = new BitmapImage();
                    await bi.SetSourceAsync(ir);
                    Main_Pic.Source = bi;
                    ApplicationData.Current.LocalSettings.Values["TempImage"] = null;
                }
                if (ApplicationData.Current.LocalSettings.Values.ContainsKey("MainPage"))
                {
                    var composite = ApplicationData.Current.LocalSettings.Values["MainPage"] as ApplicationDataCompositeValue;
                    Title.Text = (string)composite["Title"];
                    Detail.Text = (string)composite["Detail"];
                    DueDate.Date = (DateTimeOffset)composite["Date"];

                    /*for (int i = 0;i < (int)composite["count"];i++)
                    {
                        string temptitle = (string)composite["Title"+i];
                        string tempdet = (string)composite["Details"+i];
                        DateTimeOffset tempdate = (DateTimeOffset)composite["Date"+i];
                        ((App)App.Current).ViewModel.AddTodoItem(temptitle, tempdet, tempdate, Main_Pic.Source);
                        //((App)App.Current).ViewModel.AddTodoItem((string)composite["Title" + i], (string)composite["Details" + i], (DateTimeOffset)composite["Date" + i], null);
                        ((App)App.Current).ViewModel.AllItems[i].completed = (bool)composite["Visible" + i.ToString()];
                    }*/
                    ApplicationData.Current.LocalSettings.Values.Remove("MainPage");
                }
            }
            




            circulationUpdate();
        }




        private void UpdatePrimaryTile(string input0, string input, string input2)
        {
            var xmlDoc = TileService.CreateTiles(new PrimaryTile(input0, input, input2));

            var updater = TileUpdateManager.CreateTileUpdaterForApplication();
            TileNotification notification = new TileNotification(xmlDoc);
            updater.Update(notification);
        }


        private void circulationUpdate()
        {
            TileUpdateManager.CreateTileUpdaterForApplication().Clear();
            for (int i = 0; i < ((App)App.Current).ViewModel.AllItems.Count(); i++)
            {
                UpdatePrimaryTile(((App)App.Current).ViewModel.AllItems[i].date.ToString(), ((App)App.Current).ViewModel.AllItems[i].title, ((App)App.Current).ViewModel.AllItems[i].detail);
                
            }
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            var db = App.conn;
            StringBuilder result = new StringBuilder("The Result is : \n");
            using (var statement = db.Prepare("SELECT * FROM TodoItem WHERE  Title LIKE ? OR Detail LIKE ? OR Date LIKE ?"))
            {
                statement.Bind(1, searchBox.Text);
                statement.Bind(2, searchBox.Text);
                statement.Bind(3, searchBox.Text);
                while (SQLiteResult.ROW == statement.Step())
                {
                    result.Append("Id: " + (long)statement[0] + " ");
                    result.Append("Title: " + (string)statement[1] + " ");
                    result.Append("Detail: " + (string)statement[2] + " ");
                    result.Append("Date: " + (string)statement[3] + " ");
                    result.Append("isCompleted: " + (((long)statement[4] == 1) ? "true" : "false"));
                    result.Append("\n");
                }
            }
            if (result.ToString().Equals("The Result is : \n"))
            {
                var i = new MessageDialog("Not found.").ShowAsync();
            }
            else
            {
                var i = new MessageDialog(result.ToString()).ShowAsync();
            }
        }


        //没有效果
        private void List_Checkbox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            var s = sender as FrameworkElement;
            var item = (Models.TodoItem)s.DataContext;
            //var i = new MessageDialog(item.title).ShowAsync();
            if (cb.IsChecked == true)
            {
                // myline1.Visibility = Windows.UI.Xaml.Visibility.Visible;
                item.completed = true;
                //App.SomeImportantValue = true;
                var db = App.conn;
                try
                {
                    using (var TodoItem = db.Prepare("UPDATE TodoItem SET Completed = ? WHERE Title = ?"))
                    {
                        TodoItem.Bind(1, ((bool)item.completed ? 1 : 0));
                        TodoItem.Bind(2, item.title);
                        TodoItem.Step();

                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                //myline1.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                item.completed = false;
                //App.SomeImportantValue = false;
                var db = App.conn;
                try
                {
                    using (var TodoItem = db.Prepare("UPDATE TodoItem SET Completed = ? WHERE Title = ?"))
                    {
                        TodoItem.Bind(1, ((bool)item.completed ? 1 : 0));
                        TodoItem.Bind(2, item.title);
                        TodoItem.Step();

                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

        
    }
}
