﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using App2.ViewModels;

namespace App2.Models
{
    public class TodoItem
    {
        public static int count = 0;
        public int id { get; set; }
        public DateTimeOffset date { get; set; }
        public ImageSource imageSource { get; set; }
        public string title { get; set; }
        public string detail { get; set; }
        public bool? completed { get; set; }
        public string imagename { get; set; }

        public TodoItem(string title, string detail, DateTimeOffset date, ImageSource image, string name)
        {
            this.id = count++;
            //this.id = Guid.NewGuid().ToString();
            this.title = title;
            this.detail = detail;
            this.completed = false;
            this.imageSource = image;
            this.date = date;
            this.imagename = name;
        }
    }
}
