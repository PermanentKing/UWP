﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using Windows.UI.Core;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.Storage.AccessCache;

// https://go.microsoft.com/fwlink/?LinkId=234238 上介绍了“空白页”项模板

namespace App2
{

    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class NewPage : Page
    {
       // public string imgstr;
        private string path;
        public string name;
        //public BitmapImage temp;

        //private ViewModels.TodoItemViewModel ViewModel;

        //private StorageFile storagefile;

        //ViewModels.TodoItemViewModel ViewModel { get; set; }


        public NewPage()
        {
            this.InitializeComponent();
            //ViewModel = ViewModels.TodoItemViewModel.getInstance();
            //rootFrame.Navigated += OnNavigated;
            //SystemNavigationManager.GetForCurrentView().BackRequested += OnBackRequested;
        }

        /*private void OnNavigated(object sender, NavigationEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;

            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility =
                ((Frame)sender).CanGoBack ?
                AppViewBackButtonVisibility.Visible :
                AppViewBackButtonVisibility.Collapsed;
            ViewModel = e.Parameter as ViewModels.TodoItemViewModel;
            if (ViewModel.SelectedItem == null)
            {
                CreateButton.Content = "Create";
            }
            else
            {
                CreateButton.Content = "Update";
                Title.Text = ViewModel.SelectedItem.title;
                Detail.Text = ViewModel.SelectedItem.detail;
                DueDate.Date = ViewModel.SelectedItem.date;
                img.Source = ViewModel.SelectedItem.imageSource;
            }
        }*/


        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            /*Frame rootFrame = Window.Current.Content as Frame;

            if (rootFrame.CanGoBack)
            {
                // Show UI in title bar if opted-in and in-app backstack is not empty.
                SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility =
                    AppViewBackButtonVisibility.Visible;
            }
            else
            {
                // Remove the UI from the title bar if in-app back stack is empty.
                SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility =
                    AppViewBackButtonVisibility.Collapsed;
            }*/
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;


            if (e.NavigationMode == NavigationMode.New)
            {
                ApplicationData.Current.LocalSettings.Values.Remove("newpages");
                ApplicationData.Current.LocalSettings.Values["TempImage"] = null;
            }
            else
            {
                if (ApplicationData.Current.LocalSettings.Values["TempImage"] != null)
                {
                    StorageFile temp;
                    temp = await StorageApplicationPermissions.FutureAccessList.GetFileAsync((string)ApplicationData.Current.LocalSettings.Values["TempImage"]);
                    IRandomAccessStream ir = await temp.OpenAsync(FileAccessMode.Read);
                    BitmapImage bi = new BitmapImage();
                    await bi.SetSourceAsync(ir);
                    img.Source = bi;
                    ApplicationData.Current.LocalSettings.Values["TempImage"] = null;
                }
                if (ApplicationData.Current.LocalSettings.Values.ContainsKey("newpages"))
                {
                    var composite = ApplicationData.Current.LocalSettings.Values["newpages"] as ApplicationDataCompositeValue;
                    Title.Text = (string)composite["title"];
                    Detail.Text = (string)composite["detail"];
                    DueDate.Date = (DateTimeOffset)composite["date"];
                    
                    ApplicationData.Current.LocalSettings.Values.Remove("newpages");
                }
            }


            //ViewModel = ((ViewModels.TodoItemViewModel)e.Parameter);
            if (((App)App.Current).ViewModel.SelectedItem == null)
            {
                CreateButton.Content = "Create";
            }
            else
            {
                CreateButton.Content = "Update";
                Title.Text = ((App)App.Current).ViewModel.SelectedItem.title;
                Detail.Text = ((App)App.Current).ViewModel.SelectedItem.detail;
                DueDate.Date = ((App)App.Current).ViewModel.SelectedItem.date;
                img.Source = ((App)App.Current).ViewModel.SelectedItem.imageSource;
                name = ((App)App.Current).ViewModel.SelectedItem.imagename;
            }
        }


        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            bool suspending = ((App)App.Current).isssuspend;
            if (suspending)
            {
                ApplicationDataCompositeValue composite = new ApplicationDataCompositeValue();
                composite["title"] = Title.Text;
                composite["detail"] = Detail.Text;
                composite["date"] = DueDate.Date;
                ApplicationData.Current.LocalSettings.Values["newpages"] = composite;
            }
        }


        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            Title.Text = "";
            Detail.Text = "";
            DueDate.Date = DateTimeOffset.Now;
        }

        private async void create_Click(object sender, RoutedEventArgs e)
        {
            String emptys = "";
            if (Title.Text.Equals(""))
            {
                emptys += (emptys.Equals("") ? "You did not set:\n" : "");
                emptys += "\tTitle\n";
            }
            if (Detail.Text.Equals(""))
            {
                emptys += (emptys.Equals("") ? "You did not set:\n" : "");
                emptys += "\tDetails\n";
            }
            if (DueDate.Date < DateTime.Now.Date)
            {
                emptys += (emptys.Equals("") ? "" : "and ");
                emptys += "the time is earlier than now";
            }
            if (!emptys.Equals(""))
            {
                ContentDialog content_dialog = new ContentDialog()
                {
                    Title = "Error",
                    Content = emptys,
                    PrimaryButtonText = "Get",
                };
                await content_dialog.ShowAsync();
            }
            else
            {
                if (CreateButton.Content.Equals("Create"))
                {
                    ((App)App.Current).ViewModel.AddTodoItem(Title.Text, Detail.Text, DueDate.Date.Date, img.Source, name);


                    Title.Text = "";
                    Detail.Text = "";
                    DueDate.Date = DateTimeOffset.Now.Date;
                    ContentDialog content_dialog = new ContentDialog()
                    {
                        Title = "Create",
                        Content = "Success!",
                        PrimaryButtonText = "OK",
                    };
                    content_dialog.PrimaryButtonClick += (_s, _e) => {
                        Frame rootFrame = Window.Current.Content as Frame;
                        if (rootFrame == null)
                            return;
                        if (rootFrame.CanGoBack)
                        {
                            rootFrame.GoBack();
                        }
                    };
                    await content_dialog.ShowAsync();
                }
                else
                {
                    ((App)App.Current).ViewModel.UpdateTodoItem(Title.Text, Detail.Text, DueDate.Date.Date, ((App)App.Current).ViewModel.SelectedItem.completed, img.Source, name);
                    ContentDialog content_dialog = new ContentDialog()
                    {
                        Title = "Update",
                        Content = "Success!",
                        PrimaryButtonText = "OK",
                    };

                    content_dialog.PrimaryButtonClick += (_s, _e) => {
                        Frame rootFrame = Window.Current.Content as Frame;
                        if (rootFrame == null)
                            return;
                        if (rootFrame.CanGoBack)
                        {
                            rootFrame.GoBack();
                        }
                    };

                    await content_dialog.ShowAsync();
                }
                
            }
        }

        /*private void home_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MainPage), "");
        }*/

        private void Title_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private async void SelectPicture_Click(object sender, RoutedEventArgs e)
        {
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".png");
            openPicker.FileTypeFilter.Add(".gif");
            String ImagePath = Directory.GetCurrentDirectory() + "\\Assets\\";
            StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(ImagePath);

            StorageFile file = await openPicker.PickSingleFileAsync();
            if (file != null)
            {

                /*var stream = await file.OpenReadAsync();
                using (var dataReader = new DataReader(stream))
                {
                    var bytes = new byte[stream.Size];
                    await dataReader.LoadAsync((uint)stream.Size);
                    dataReader.ReadBytes(bytes);
                    imgstr = System.Text.Encoding.Unicode.GetString(bytes);
                }*/
                ApplicationData.Current.LocalSettings.Values["TempImage"] = StorageApplicationPermissions.FutureAccessList.Add(file);

                StorageFile newFile = await file.CopyAsync(folder, file.Name, 0);

                if (newFile != null)
                {
                    using (Windows.Storage.Streams.IRandomAccessStream fileStream =
                await newFile.OpenAsync(FileAccessMode.Read))
                    {
                        Windows.UI.Xaml.Media.Imaging.BitmapImage bitmapImage =
                            new Windows.UI.Xaml.Media.Imaging.BitmapImage();
                        bitmapImage.SetSource(fileStream);
                        img.Source = bitmapImage;
                        name = file.Name;
                    }
                }

            }
        }


        private async void setDefaultImage()
        {
            String ImagePath = Directory.GetCurrentDirectory() + "\\Assets\\";
            StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(ImagePath);
            StorageFile file = await folder.GetFileAsync("background.jpg");
            using (Windows.Storage.Streams.IRandomAccessStream fileStream =
                    await file.OpenAsync(FileAccessMode.Read))
            {
                Windows.UI.Xaml.Media.Imaging.BitmapImage bitmapImage =
                    new Windows.UI.Xaml.Media.Imaging.BitmapImage();
                bitmapImage.SetSource(fileStream);
                img.Source = bitmapImage;
                name = file.Name;
            }
        }
    }
}
