﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Controls;
using App2.Models;
using SQLitePCL;
using Windows.Storage;
using System.IO;


namespace App2.ViewModels
{
    public class TodoItemViewModel
    {
        private ObservableCollection<Models.TodoItem> allItems = new ObservableCollection<Models.TodoItem>();
        public ObservableCollection<Models.TodoItem> AllItems { get { return this.allItems; } }

        private Models.TodoItem selectedItem = default(Models.TodoItem);
        public Models.TodoItem SelectedItem { get { return selectedItem; } set { this.selectedItem = value; } }

        public static TodoItemViewModel instance;

        public ImageSource image;

        public TodoItemViewModel()
        {
            var db = App.conn;
            using (var statement = db.Prepare("SELECT * FROM TodoItem"))
            {
                while (SQLiteResult.ROW == statement.Step())
                {
                    string temp = (string)statement[5];
                    //getImage(temp);
                    image = null;
                    var tempI = new Models.TodoItem((string)statement[1],
                        (string)statement[2], DateTimeOffset.Parse((string)statement[3]), image, temp);
                    tempI.completed = (((long)statement[4]) == 1) ? true : false;
                    this.allItems.Add(tempI);
                }
            }
            if (allItems.Count != 0)
            {
                TodoItem.count = allItems[allItems.Count - 1].id + 2;
            }

        }


        public static TodoItemViewModel getInstance()
        {
            if (instance == null)
            {
                instance = new TodoItemViewModel();
            }
            return instance;
        }

        public void AddTodoItem(string title, string detail, DateTimeOffset date, ImageSource image, string name)
        {
            TodoItem temp = new Models.TodoItem(title, detail, date, image, name);
            this.allItems.Add(temp);


            var db = App.conn;
            using (var todoItem = db.Prepare("INSERT INTO TodoItem(Id, Title, Detail," +
                                             "Completed, Date, Name) VALUES (?, ?, ?, ?, ?, ?)"))
            {
                todoItem.Bind(1, temp.id);
                todoItem.Bind(2, temp.title);
                todoItem.Bind(3, temp.detail);
                todoItem.Bind(4, ((bool)temp.completed ? 1 : 0));
                todoItem.Bind(5, temp.date.ToString());
                todoItem.Bind(6, temp.imagename);
                todoItem.Step();
            }

        }

        public void RemoveTodoItem()
        {
            var db = App.conn;
            using (var statement = db.Prepare("DELETE FROM TodoItem WHERE Id = ?"))
            {
                statement.Bind(1, (long)SelectedItem.id);
                statement.Step();
            }

            allItems.Remove(SelectedItem);
            SelectedItem = null;
            this.selectedItem = null;
            //Models.TodoItem.count--;
        }

        public void UpdateTodoItem(string title, string detail, DateTimeOffset date, bool? completed, ImageSource image, string name)
        {

            SelectedItem.title = title;
            SelectedItem.detail = detail;
            SelectedItem.date = date;
            SelectedItem.completed = completed;
            SelectedItem.imageSource = image;
            selectedItem.imagename = name;


            var db = App.conn;
            using (var todoItem = db.Prepare("UPDATE TodoItem SET Title = ?, Detail = ?, Date = ?, Completed = ?, Name = ? WHERE Id = ?"))
            {
                todoItem.Bind(1, SelectedItem.title);
                todoItem.Bind(2, SelectedItem.detail);
                todoItem.Bind(3, SelectedItem.date.ToString());
                todoItem.Bind(4, SelectedItem.completed == true ? 1 : 0);
                todoItem.Bind(5, SelectedItem.imagename);
                todoItem.Bind(6, SelectedItem.id);
                todoItem.Step();
            }
        }


        private async void getImage(string name)
        {
            String ImagePath = Directory.GetCurrentDirectory() + "\\Assets\\";
            StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(ImagePath);
            StorageFile file = await folder.GetFileAsync(name);
            using (Windows.Storage.Streams.IRandomAccessStream fileStream =
                    await file.OpenAsync(FileAccessMode.Read))
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.SetSource(fileStream);
                image = bitmapImage;
                
            }
        }




    }
}
