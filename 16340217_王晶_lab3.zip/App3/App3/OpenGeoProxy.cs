﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace App3
{
    class OpenGeoProxy
    {
        //百度api
        private static string url = @"http://api.map.baidu.com/geocoder/v2/?location={0}&output=json&ak=WEc8RlPXzSifaq9RHxE1WW7lRKgbid6Y";

        /// <summary>
        /// 根据经纬度获取地理位置
        /// </summary>
        /// <param name="lat">纬度</param>
        /// <param name="lng">经度</param>
        /// <returns>具体的地埋位置</returns>
        public static JsonObject GetGeoInformation(string lat, string lng)
        {
            HttpClient client = new HttpClient();
            string location = string.Format("{0},{1}", lat, lng);
            string bdUrl = string.Format(url, location);
            string result = client.GetStringAsync(bdUrl).Result;
            var rootObject = JsonObject.Parse(result);
            JsonObject res = rootObject["result"].GetObject();
            JsonObject res2 = res["addressComponent"].GetObject();
            return res2;
        }
    }
}
