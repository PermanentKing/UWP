﻿using AlbumCoverMatchGame.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.FileProperties;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using AlbumCoverMatchGame.Services;
using Windows.UI.Notifications;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace AlbumCoverMatchGame
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private ObservableCollection<Song> Songs;
        private ObservableCollection<StorageFile> AllSongs;

        bool _playingMusic = false;
        int _round = 0;
        int _totalScore = 0;

        public MainPage()
        {
            this.InitializeComponent();
            Songs = new ObservableCollection<Song>();

        }



        private async Task RetrieveFilesInFolders(
            ObservableCollection<StorageFile> list,
            StorageFolder parent)
        {
            foreach (var item in await parent.GetFilesAsync())
            {
                //只能加mp3哦
                if (item.FileType == ".mp3")
                {
                    list.Add(item);
                }

            }
            foreach (var item in await parent.GetFoldersAsync())
            {
                await RetrieveFilesInFolders(list, item);
            }
        }


        private async Task<List<StorageFile>> PickRandomSongs(ObservableCollection<StorageFile> allSongs)
        {
            Random random = new Random();
            var songCount = allSongs.Count;

            var randomSongs = new List<StorageFile>();



            while (randomSongs.Count < 10)
            {
                var randomNumber = random.Next(songCount);
                var randomSong = allSongs[randomNumber];


                MusicProperties randomSongMusicProperties =
                    await randomSong.Properties.GetMusicPropertiesAsync();

                bool isDuplicate = false;

                foreach (var song in randomSongs)
                {
                    MusicProperties songMusicProperties = await song.Properties.GetMusicPropertiesAsync();
                    if (String.IsNullOrEmpty(randomSongMusicProperties.Album)
                        || randomSongMusicProperties.Album == songMusicProperties.Album)
                        isDuplicate = true;
                }

                if (!isDuplicate)
                    randomSongs.Add(randomSong);
            }
            return randomSongs;
        }

        private async Task PopulateSongList(List<StorageFile> files)
        {
            int id = 0;

            foreach (var file in files)
            {
                MusicProperties songProperties = await file.Properties.GetMusicPropertiesAsync();

                StorageItemThumbnail currentThumb = await file.GetThumbnailAsync(
                    ThumbnailMode.MusicView, 200, ThumbnailOptions.UseCurrentScale);
                var albumCover = new BitmapImage();
                albumCover.SetSource(currentThumb);

                var song = new Song();
                song.Id = id;
                song.Title = songProperties.Title;
                song.Artist = songProperties.Artist;
                song.Album = songProperties.Album;
                song.AlbumCover = albumCover;
                song.SongFile = file;

                Songs.Add(song);
                id++;
            }
        }

        private async void SongGridView_ItemClick(object sender, ItemClickEventArgs e)
        {
            //在准备期间即使点击了封面也无反应
            if (!_playingMusic) return;
            CountDown.Pause();
            MyMediaElement.Stop();

            var clickedSong = (Song)e.ClickedItem;
            //查找正确歌曲信息
            var correctSong = Songs.FirstOrDefault(p => p.Selected == true);
            //判断正误
            // Evaluate the user's selection

            Uri uri;
            int score;

            if (clickedSong.Selected)
            {
                uri = new Uri("ms-appx:///Assets/correct.png");
                score = (int)MyProgressBar.Value;
            }
            else
            {
                uri = new Uri("ms-appx:///Assets/incorrect.png");
                score = ((int)MyProgressBar.Value) * -1;
            }

            StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(uri);
            var fileStream = await file.OpenAsync(FileAccessMode.Read);
            await clickedSong.AlbumCover.SetSourceAsync(fileStream);

            _totalScore += score;
            _round++;

            //ResultTextBlock.Text = string.Format("分数: {0} Total Score After {1} Rounds: {2}", score, _round, _totalScore);
            ResultTextBlock.Text = string.Format("局数: {0}  分数：{1}", _round, _totalScore);
            TitleTextBlock.Text = string.Format("歌曲: {0}", correctSong.Title);
            ArtistTextBlock.Text = string.Format("歌手: {0}", correctSong.Artist);
            AlbumTextBlock.Text = string.Format("专辑: {0}", correctSong.Album);

            clickedSong.Used = true;

            correctSong.Selected = false;
            correctSong.Used = true;

            if (_round >= 5)
            {
                InstructionTextBlock.Text = string.Format("游戏结束 你的分数为: {0}", _totalScore);
                PlayAgainButton.Visibility = Visibility.Visible;
            }
            else
            {
                StartCoolDown();
            }

        }

        private async void PlayAgainButton_Click(object sender, RoutedEventArgs e)
        {
            await PrepareNewGame();
            PlayAgainButton.Visibility = Visibility.Collapsed;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {



        }

        private async Task<ObservableCollection<StorageFile>> SetupMusicList()
        {
            //进入你的歌曲目录
            StorageFolder folder = KnownFolders.MusicLibrary;
            var allSongs = new ObservableCollection<StorageFile>();
            await RetrieveFilesInFolders(allSongs, folder);
            return allSongs;
        }

        private async Task PrepareNewGame()
        {
            Songs.Clear();

            //随机选择歌曲
            var randomSongs = await PickRandomSongs(AllSongs);

            //等待导入歌曲信息
            await PopulateSongList(randomSongs);

            StartCoolDown();
            //声明信息模板
            InstructionTextBlock.Text = "准备！";
            ResultTextBlock.Text = "";
            TitleTextBlock.Text = "";
            ArtistTextBlock.Text = "";
            AlbumTextBlock.Text = "";

            _totalScore = 0;
            _round = 0;


        }

        private async void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            StartupProgressRing.IsActive = true;

            AllSongs = await SetupMusicList();
            await PrepareNewGame();

            StartupProgressRing.IsActive = false;

            StartCoolDown();
        }

        private void StartCoolDown()
        {
            _playingMusic = false;
            SolidColorBrush brush = new SolidColorBrush(Colors.Green);
            MyProgressBar.Foreground = brush;
            InstructionTextBlock.Text = string.Format("即将开始第{0}轮匹配", _round + 1);
            InstructionTextBlock.Foreground = brush;
            CountDown.Begin();
        }

        private void StartCountdown()
        {
            _playingMusic = true;
            SolidColorBrush brush = new SolidColorBrush(Colors.Red);
            MyProgressBar.Foreground = brush;
            InstructionTextBlock.Text = "请选择相匹配的封面!";
            InstructionTextBlock.Foreground = brush;
            CountDown.Begin();

        }

        private async void CountDown_Completed(object sender, object e)
        {
            if (!_playingMusic)
            {
                //开始播放音乐
                var song = Picksong();



                MyMediaElement.SetSource(
                    await song.SongFile.OpenAsync(FileAccessMode.Read),
                    song.SongFile.ContentType);

                //开始倒计时
                StartCountdown();

            }
        }

        private Song Picksong()
        {
            Random random = new Random();
            var unusedSongs = Songs.Where(p => p.Used == false);
            var randomNumber = random.Next(unusedSongs.Count());
            var randomSong = unusedSongs.ElementAt(randomNumber);
            randomSong.Selected = true;
            UpdatePrimaryTile(randomSong.Title, randomSong.Artist, randomSong.Album);
            return randomSong;
        }


        private void UpdatePrimaryTile(string input0, string input, string input2)
        {
            var xmlDoc = TileService.CreateTiles(new PrimaryTile(input0, input, input2));

            var updater = TileUpdateManager.CreateTileUpdaterForApplication();
            TileNotification notification = new TileNotification(xmlDoc);
            updater.Update(notification);
        }


        private void circulationUpdate()
        {
            TileUpdateManager.CreateTileUpdaterForApplication().Clear();
            for (int i = 0; i < Songs.Count - 7; i++)
            {
                UpdatePrimaryTile(Songs[i].Title, Songs[i].Artist, Songs[i].Album);
                AlbumTextBlock.Text += Songs[i].Title;
            }
            
            
        }

    }
}
