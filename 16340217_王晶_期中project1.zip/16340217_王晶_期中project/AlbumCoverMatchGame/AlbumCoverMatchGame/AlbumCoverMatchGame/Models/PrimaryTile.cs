﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlbumCoverMatchGame.Models
{
    class PrimaryTile
    {
        public string time
        {
            set;
            get;
        } = "Artist";
        public string message
        {
            set;
            get;
        } = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed  do eiusmod tempor incididunt ut labore.";
        public string message2
        {
            set;
            get;
        } = "At vero eos et accusamus et iusto odio dignissimos ducimus  qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias  excepturi sint occaecati cupiditate non provident.";
        public string branding
        {
            set;
            get;
        } = "name";
        public string appName
        {
            set;
            get;
        } = "Album Match";

        public PrimaryTile(string input0, string input, string input2)
        {
            time = input0;
            message = input;
            message2 = input2;
        }
    }
}
